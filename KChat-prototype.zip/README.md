# KChat prototype for KOReader

KChat is a minimal Kobo-to-Kobo chat prototype for KOReader. It sends one
UTF-8 message per direct TCP connection over the same Wi-Fi network.

This first milestone intentionally has:

- no cloud service or accounts;
- no peer discovery;
- no encryption or authentication;
- no saved history;
- customizable aliases for this Kobo and its peer;
- one manually configured peer IPv4 address and TCP port (default `57321`).

## Install

1. Connect each Kobo to a computer by USB.
2. Copy the complete `kchat.koplugin` directory into the KOReader `plugins`
   directory on **both** devices. The result must be:

   ```text
   .adds/koreader/plugins/kchat.koplugin/
   ├── _meta.lua
   ├── main.lua
   └── kchat_protocol.lua
   ```

3. Safely eject each Kobo and restart KOReader completely.
4. If KChat is disabled, enable it under **Tools → Plugin management**, then
   restart KOReader once more.

KChat appears in KOReader's **Tools** menu in both the file browser and reader.

## First two-device test

Keep both Kobos awake, connected to the same normal Wi-Fi network, and leave
KOReader open. Guest networks often block devices from talking to each other.

On **Kobo B** (the receiver):

1. Find its IPv4 address in the router's connected-device list or the Kobo
   network information screen. Example: `192.168.1.42`.
2. Open **Tools → KChat**.
3. Tap **Start listener (port 57321)**.
4. Leave KOReader running and Wi-Fi connected.

On **Kobo A** (the sender):

1. Open **Tools → KChat → Peer: not set:57321**.
2. Choose the alias this Kobo sends with its messages. Optionally give Kobo B
   a local nickname, enter Kobo B's IPv4 address, and keep port `57321`.
3. Tap **Save**.
4. Tap **Send a message**, enter `hello from kobo 👋`, and tap **Send**.

Expected result:

- Kobo A says **KChat message sent** and records the outgoing text in its log.
- Within about a second, Kobo B shows a new-message notification.
- **Tools → KChat → Open chat log** on Kobo B shows the sender's IP and the
  exact UTF-8 text.

To test the other direction, start the listener on Kobo A, configure Kobo B
with Kobo A's IPv4 address, and send back.

## Wire protocol

Each connection carries exactly one frame and then closes:

```text
KCHAT/1\n
MSG <alias-byte-length> <message-byte-length>\n
<raw alias bytes><raw message bytes>
```

Example:

```text
KCHAT/1
MSG 4 15
Kobohello from kobo
```

The receiver polls nonblocking sockets from KOReader's UI scheduler, caps a
message at 16 KiB, rejects malformed frames, and drops incomplete clients after
10 seconds. Message length is a byte count, so multibyte UTF-8 text remains
intact.

## Troubleshooting

- **Connection refused:** start the listener on the receiving Kobo and confirm
  both devices use the same port.
- **Timeout / unreachable:** recheck the receiver's current IPv4 address and
  confirm both devices are on the same Wi-Fi. Disable router "AP isolation" or
  "client isolation" if enabled.
- **KChat is missing:** verify the directory is named exactly
  `kchat.koplugin`, contains `_meta.lua` directly, and restart KOReader.
- **It worked, then stopped:** Kobo may suspend or turn Wi-Fi off. Wake both
  devices, confirm Wi-Fi is connected, and restart the listener if necessary.
- **Port already in use:** select the same unused port from 1024–65535 on both
  devices. Prefer the default unless another service already occupies it.

## Security boundary

This prototype is plaintext and unauthenticated. Anyone able to reach the
listening Kobo on the local network can read traffic in transit or send it a
message. Use it only on a trusted LAN. Pairing, encryption, discovery, message
history, delivery acknowledgements, and persistent conversations are explicitly
future work.
